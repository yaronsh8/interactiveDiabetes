const path = require('path');
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");

module.exports = {
  entry: './src/index.js',
  output: {
    filename: 'static/js/app.bundle.js',
    path: path.resolve(__dirname, 'dist')
  },
  module: {
    rules: [
      // { test:/\.js$/, use: 'babel-loader' , exclude: /node_modules/ },
      // {
      //   test: /\.scss$/,
      //   use: ['style-loader', 'css-loader', 'sass-loader']
      // },
      {
        test: /\.(jpe?g|png|gif|svg)$/i,
        loader: 'url-loader'
        // use: [
        //   'url-loader',
        //   'img-loader',
        //   'file-loader'
        // ]
      },
      {
         test: /\.scss$/,
         use: ExtractTextPlugin.extract({
           fallback: "style-loader",
           use: "css-loader!sass-loader"
         })
      },
    ]
  },
  plugins: [
    new ExtractTextPlugin("static/css/globals.css"),
    new CopyWebpackPlugin([{
        from: 'src/index.html'
      },
      {
        from: 'src/static/images',
        to: 'static/images'
      },
    ])
  ],
  devServer: {
    contentBase: path.join(__dirname, "dist"),
    compress: true,
    port: 3000,
    stats: "minimal",
    open: true,
    openPage: ""
  },
  devtool: "source-map"
};