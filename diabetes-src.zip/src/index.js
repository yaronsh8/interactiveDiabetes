import main from './sass/main.scss';
import $ from 'jquery';
import TweenLite from "gsap";

$(document).ready(function () {
    console.log('anim.js');
    var animBg = document.getElementById("animBG"),
        jqSugarRange = $('.sugarRange'),
        jsSugarValue = $('.sugarValue'),
        jsExplanation = $('.explanation'),
        jsInstruction = $('.instruction'),
        jsAnim = $('#anim'),
        isDiabetec = false,
        isDiabetecPrev = null,
        elementCreationControl,
        diabetecBoxesCounter = 1;

    jqSugarRange.on('input', function (e) {
        // jsSugarValue.html('Blood Glucose: ' + e.currentTarget.value);
        if (e.currentTarget.value > 126) {
            
        jsSugarValue.html('רמת גלוקוז (סוכר) גבוהה בדם: ' + e.currentTarget.value);
        }else{
        jsSugarValue.html('רמת גלוקוז (סוכר) תקינה בדם: ' + e.currentTarget.value);
        }
    })

    jqSugarRange.change(function (e) {
        if (e.currentTarget.value > 126) {
            if (isDiabetec == true) {
                return;
            } else {
                isDiabetec = true;
                $('.glucose').addClass("fadeOut");
                $('.insulin').addClass("disappear");
                jsExplanation.html("אינסולין <b>לא</b> מיוצר בלבלב . הגלוקוז נשאר במחזור הדם ולא נכנס אל התאים. ההשפעות הן חולשה כללית ונזק לכלי הדם")
                jsInstruction.html("הזז את הידית מתחת ל-126 כדי לחזור למצב תקין")
                diabetecBoxesCounter = 0;

            }
        } else {
            if (isDiabetec == false) {
                return;
            } else {
                isDiabetec = false;
                $('.cell.fatigued').removeClass('fatigued');
                $('.glucoseBox.diabetec').find(".glucose").addClass("fadeOut");
                jsExplanation.html("אינסולין מיוצר בלבלב ומאפשר לגלוקוז לצאת ממחזור הדם אל התאים ולהזין אותם")                
                jsInstruction.html("הזז את הידית כדי להעלות את רמת הגלוקוז מעל 126 ולעבור למצב של סוכרת")                
                setTimeout(function () {
                    $('.glucoseBox.diabetec').remove();
                }, 1000)
            }
        }
        clearTimeout(elementCreationControl);
        playAnimation();
        $(".expText").toggleClass('hidden');
        jsAnim.toggleClass("healthy");
        
    })

    playAnimation();

    function playAnimation() {
        isDiabetec ? playDiabetecState() : playNormalState();
    }

    function playNormalState() {
        let newGlucoseBox = createNewGlucoseBox();
        let newInsulinBox = createNewInsulinBox();
        setTimeout(function () {
            removeGlucose(newGlucoseBox);
            removeInsulin(newInsulinBox);
        }, 6000);
        elementCreationControl = setTimeout(playNormalState, 2500);
        document.getElementsByClassName("cell")[0].classList.add("energized");
    }

    function playDiabetecState() {
        const MAX_BOXES=10;
        let newGlucoseBox = createNewGlucoseBox();
        newGlucoseBox.classList.add("diabetec");
        diabetecBoxesCounter++;
        console.log(diabetecBoxesCounter);
        diabetecBoxesCounter < MAX_BOXES && (elementCreationControl = setTimeout(playDiabetecState, 2500));
        document.getElementsByClassName("cell")[0].classList.add("fatigued");
    }

    function removeGlucose(glucoseBox) {
        glucoseBox.children[0].classList.add("disappear");
        setTimeout(function () {
            $(glucoseBox).remove();
        }, 2000);

    }

    function removeInsulin(insulinBox) {
        insulinBox.children[0].classList.add("disappear");
        setTimeout(function () {
            $(insulinBox).remove();
        }, 2000);

    }

    function createNewGlucoseBox() {
        var glucoseBox = document.createElement("div");
        var glucose = document.createElement("div");
        var sideTop = document.createElement("div");
        var sideLeft = document.createElement("div");
        var sideRight = document.createElement("div");
        glucoseBox.classList.add("glucoseBox");
        isDiabetec && glucoseBox.classList.add("diabetec");
        glucose.classList.add("glucose");
        sideTop.classList.add("side", "top")
        sideLeft.classList.add("side", "left")
        sideRight.classList.add("side", "right")
        animBg.appendChild(glucoseBox);
        glucose.appendChild(sideTop);
        glucose.appendChild(sideLeft);
        glucose.appendChild(sideRight);
        glucoseBox.appendChild(glucose);

        return glucoseBox;
    }

    function createNewInsulinBox() {
        var insulinBox = document.createElement("div");
        var insulin = document.createElement("div");
        // insulin.innerHTML = "G";
        // insulin.style.fontSize = "3rem";
        // insulin.style.textAlign = "center";
        // insulin.style.lineHeight = "6.4rem";
        insulinBox.classList.add("insulinBox");
        insulin.classList.add("insulin");
        animBg.appendChild(insulinBox);
        insulinBox.appendChild(insulin);
        return insulinBox;

    }

})